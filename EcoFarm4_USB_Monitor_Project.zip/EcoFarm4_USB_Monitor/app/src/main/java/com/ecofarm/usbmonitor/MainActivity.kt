package com.ecofarm.usbmonitor

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.app.Activity
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.hoho.android.usbserial.util.SerialInputOutputManager
import java.util.concurrent.Executors
import java.util.regex.Pattern

class MainActivity : Activity(), SerialInputOutputManager.Listener {
    private lateinit var usbManager: UsbManager
    private lateinit var connectionText: TextView
    private lateinit var tempValue: TextView
    private lateinit var humidityValue: TextView
    private lateinit var soilValue: TextView
    private lateinit var tankValue: TextView
    private lateinit var pumpValue: TextView
    private lateinit var logValue: TextView
    private lateinit var connectButton: Button
    private var port: UsbSerialPort? = null
    private var ioManager: SerialInputOutputManager? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val lineBuffer = StringBuilder()
    private val actionUsbPermission = "com.ecofarm.usbmonitor.USB_PERMISSION"

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == actionUsbPermission) {
                val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                if (granted) openSerial() else setConnection("USB permission denied", false)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        buildDashboard()
        val filter = IntentFilter(actionUsbPermission)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(permissionReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(permissionReceiver, filter)
        setConnection("Connect Arduino using USB OTG", false)
    }

    private fun buildDashboard() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.WHITE) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "ECOFARM 4.0"
            textSize = 29f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setTextColor(Color.rgb(37, 99, 235))
            gravity = Gravity.CENTER
        }
        page.addView(title)
        page.addView(label("SMART AGRICULTURE MONITOR", "#64748B", 11f, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(16))
        })

        val statusCard = card("#EFF6FF")
        connectionText = label("● DISCONNECTED", "#1D4ED8", 14f, true)
        statusCard.addView(connectionText)
        page.addView(statusCard)

        val grid1 = row()
        grid1.addView(metricCard("TEMPERATURE", "—", "°C", "#EFF6FF", "#2563EB").apply { tempValue = findViewWithTag("value") })
        grid1.addView(metricCard("HUMIDITY", "—", "%", "#F0FDF4", "#15803D").apply { humidityValue = findViewWithTag("value") })
        page.addView(grid1)

        val grid2 = row()
        grid2.addView(metricCard("SOIL MOISTURE", "—", "%", "#FFF7ED", "#C2410C").apply { soilValue = findViewWithTag("value") })
        grid2.addView(metricCard("WATER TANK", "—", "%", "#F5F3FF", "#6D28D9").apply { tankValue = findViewWithTag("value") })
        page.addView(grid2)

        val irrigation = card("#F0FDF4")
        irrigation.addView(label("IRRIGATION STATUS", "#475569", 12f, true))
        pumpValue = label("Waiting for Arduino…", "#15803D", 22f, true)
        pumpValue.setPadding(0, dp(8), 0, dp(3))
        irrigation.addView(pumpValue)
        irrigation.addView(label("Pump activity reported by your Arduino", "#64748B", 12f, false))
        page.addView(irrigation)

        connectButton = Button(this).apply {
            text = "CONNECT USB ARDUINO"
            textSize = 14f
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(37, 99, 235)))
            setOnClickListener { requestUsb() }
        }
        page.addView(connectButton, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(12); bottomMargin = dp(12)
        })

        val logCard = card("#F8FAFC")
        logCard.addView(label("LIVE SERIAL DATA", "#334155", 13f, true))
        logValue = label("Incoming Arduino messages will appear here.", "#64748B", 12f, false)
        logValue.setPadding(0, dp(8), 0, 0)
        logCard.addView(logValue)
        page.addView(logCard)
    }

    private fun metricCard(name: String, initial: String, unit: String, bg: String, fg: String): LinearLayout {
        val box = card(bg)
        box.layoutParams = LinearLayout.LayoutParams(0, dp(126), 1f).apply {
            if (name == "TEMPERATURE" || name == "SOIL MOISTURE") rightMargin = dp(7)
            else leftMargin = dp(7)
            bottomMargin = dp(14)
        }
        box.addView(label(name, "#475569", 11f, true))
        val value = label("$initial$unit", fg, 28f, true)
        value.tag = "value"
        value.setPadding(0, dp(10), 0, 0)
        box.addView(value)
        return box
    }

    private fun requestUsb() {
        val drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        if (drivers.isEmpty()) {
            setConnection("No compatible USB serial device found", false)
            Toast.makeText(this, "Check OTG, USB cable and Arduino power.", Toast.LENGTH_LONG).show()
            return
        }
        val device = drivers[0].device
        if (usbManager.hasPermission(device)) openSerial()
        else {
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                        else PendingIntent.FLAG_UPDATE_CURRENT
            val permissionIntent = PendingIntent.getBroadcast(this, 0, Intent(actionUsbPermission).setPackage(packageName), flags)
            usbManager.requestPermission(device, permissionIntent)
            setConnection("Waiting for USB permission…", false)
        }
    }

    private fun openSerial() {
        try {
            val driver = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager).firstOrNull()
                ?: throw IllegalStateException("No USB serial driver found")
            val connection = usbManager.openDevice(driver.device)
                ?: throw IllegalStateException("Could not open USB device")
            val serialPort = driver.ports[0]
            serialPort.open(connection)
            // Keep in sync with Serial.begin(...) in your Arduino sketch.
            serialPort.setParameters(9600, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            port = serialPort
            ioManager = SerialInputOutputManager(serialPort, this).also { executor.submit(it) }
            setConnection("● USB CONNECTED · 9600 BAUD", true)
            connectButton.text = "USB CONNECTED"
        } catch (e: Exception) {
            setConnection("Connection failed: ${e.message ?: "unknown error"}", false)
        }
    }

    override fun onNewData(data: ByteArray) {
        val incoming = String(data, Charsets.UTF_8)
        runOnUiThread {
            incoming.forEach { ch ->
                if (ch == '\n' || ch == '\r') {
                    val line = lineBuffer.toString().trim()
                    lineBuffer.clear()
                    if (line.isNotEmpty()) parseLine(line)
                } else if (lineBuffer.length < 500) lineBuffer.append(ch)
            }
        }
    }

    private fun parseLine(line: String) {
        logValue.text = line
        fun get(vararg keys: String): String? {
            for (key in keys) {
                val regex = Pattern.compile("(?i)(?:^|[,;\\s])" + Pattern.quote(key) + "\\s*[:=]\\s*([^,;\\s]+)")
                val match = regex.matcher(line)
                if (match.find()) return match.group(1)
            }
            return null
        }
        get("TEMP", "TEMPERATURE")?.let { tempValue.text = withUnit(it, "°C") }
        get("HUM", "HUMIDITY")?.let { humidityValue.text = withUnit(it, "%") }
        get("SOIL", "MOISTURE", "SOIL_MOISTURE")?.let { soilValue.text = withUnit(it, "%") }
        get("TANK", "WATER", "WATER_TANK")?.let { tankValue.text = withUnit(it, "%") }
        get("PUMP", "IRRIGATION", "STATUS")?.let {
            val active = it.equals("ON", true) || it.equals("ACTIVE", true) || it.equals("1", true) || it.equals("WATERING", true)
            pumpValue.text = if (active) "● WATERING PLANTS" else "● PUMP OFF"
            pumpValue.setTextColor(if (active) Color.rgb(21, 128, 61) else Color.rgb(100, 116, 139))
        }
    }

    private fun withUnit(value: String, unit: String): String =
        if (value.endsWith(unit, true)) value else "$value$unit"

    override fun onRunError(e: Exception) {
        runOnUiThread { setConnection("Serial error: ${e.message ?: "connection lost"}", false) }
    }

    private fun setConnection(message: String, connected: Boolean) {
        connectionText.text = message
        connectionText.setTextColor(if (connected) Color.rgb(21, 128, 61) else Color.rgb(29, 78, 216))
    }

    private fun card(color: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(15), dp(16), dp(15))
        background = GradientDrawable().apply {
            setColor(Color.parseColor(color))
            cornerRadius = dp(18).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(14)
        }
    }

    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(-1, -2)
    }

    private fun label(text: String, color: String, size: Float, bold: Boolean) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.parseColor(color))
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        try { unregisterReceiver(permissionReceiver) } catch (_: Exception) {}
        ioManager?.stop()
        try { port?.close() } catch (_: Exception) {}
        executor.shutdownNow()
        super.onDestroy()
    }
}
