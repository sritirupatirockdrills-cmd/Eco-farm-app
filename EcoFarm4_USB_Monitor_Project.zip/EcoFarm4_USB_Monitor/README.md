# EcoFarm 4.0 USB Monitor

Android app project for an Arduino Uno connected to an Android phone using USB OTG.

## Build the installable APK
This workspace does not include the Android SDK, so the APK must be built using GitHub Actions or Android Studio.

### Easiest build route (GitHub Actions)
1. Create a new GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Run **Build EcoFarm Android APK** (or push to `main`).
4. Open the completed workflow run and download the artifact named `EcoFarm4-USB-Monitor-APK`.
5. Extract `app-debug.apk` and install it on your Android phone. Android may ask you to allow installs from that file manager/browser.

### Arduino serial format
Set the Arduino sketch to `Serial.begin(9600)` and send one line per update, for example:

`TEMP:28,HUM:65,SOIL:42,TANK:85,PUMP:ON`

The app recognises these keys (case-insensitive):
- `TEMP` / `TEMPERATURE`
- `HUM` / `HUMIDITY`
- `SOIL` / `MOISTURE` / `SOIL_MOISTURE`
- `TANK` / `WATER` / `WATER_TANK`
- `PUMP` / `IRRIGATION` / `STATUS`

Use a newline at the end of each record (`Serial.println(...)`). The app uses 9600 baud, 8 data bits, no parity, 1 stop bit.

## Hardware notes
- Use a USB OTG adapter that supports USB host mode and a data-capable USB cable.
- Connect Arduino by USB. Do not connect the pump or other high-current loads to the phone's USB supply.
- The app only displays values reported by the Arduino; the Arduino sketch must calculate and transmit the tank percentage and other readings.
- USB serial support depends on the USB-to-serial chipset and Android device compatibility.
